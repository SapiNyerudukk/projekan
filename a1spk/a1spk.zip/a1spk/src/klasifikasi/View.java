/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package klasifikasi;

import com.mysql.jdbc.Connection;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import koneksidatabase.KoneksiDatabase;

/**
 *
 * @author Adzhana
 */
public class View extends javax.swing.JFrame {

    private DefaultTableModel tabel_datasetreal;
    private DefaultTableModel tabeltrainingangka;
    private DefaultTableModel tabeltesting;
    private DefaultTableModel tabeltestingangka;
    private DefaultTableModel tabel_trainingxij;
    private DefaultTableModel tabel_trainingpbest;
    private DefaultTableModel tabel_prosestraining;
    private DefaultTableModel tabel_akurasi_gbest;
    private DecimalFormat numformat;
    private DecimalFormat numformat1;
    private DecimalFormat numformat2;

    /**
     * Creates new form View
     */
    public View() {
        numformat = new DecimalFormat("0.00");
        numformat1 = new DecimalFormat("0.000000");
        numformat2 = new DecimalFormat("0.0");

        initComponents();
        tabel_datasetreal = new DefaultTableModel();
        tabel_datatraining.setModel(tabel_datasetreal);
        tabel_datasetreal.addColumn("Id");
        tabel_datasetreal.addColumn("Nama Ikan");
        tabel_datasetreal.addColumn("F1");
        tabel_datasetreal.addColumn("F2");
        tabel_datasetreal.addColumn("F3");
        tabel_datasetreal.addColumn("F4");
        tabel_datasetreal.addColumn("F5");
        tabel_datasetreal.addColumn("F6");
        tabel_datasetreal.addColumn("F7");
        tabel_datasetreal.addColumn("Actual");
        tabel_datasetreal.addColumn("Kelas_y");

//        
        //proses untuk menampilkan training Xij
        tabel_trainingxij = new DefaultTableModel();
        tabel_training_xij.setModel(tabel_trainingxij);
        tabel_trainingxij.addColumn("Partikel");
        tabel_trainingxij.addColumn("λ");
        tabel_trainingxij.addColumn("C");
        tabel_trainingxij.addColumn("γ");
        tabel_trainingxij.addColumn("F1");
        tabel_trainingxij.addColumn("F2");
        tabel_trainingxij.addColumn("F3");
        tabel_trainingxij.addColumn("F4");
        tabel_trainingxij.addColumn("F5");
        tabel_trainingxij.addColumn("F6");
        tabel_trainingxij.addColumn("F7");
        tabel_trainingxij.addColumn("fitness");
        tabel_trainingxij.addColumn("f1");
        tabel_trainingxij.addColumn("f");

        tabel_trainingpbest = new DefaultTableModel();
        tabel_training_pbest.setModel(tabel_trainingpbest);
        tabel_trainingpbest.addColumn("Partikel");
        tabel_trainingpbest.addColumn("λ");
        tabel_trainingpbest.addColumn("C");
        tabel_trainingpbest.addColumn("γ");
        tabel_trainingpbest.addColumn("F1");
        tabel_trainingpbest.addColumn("F2");
        tabel_trainingpbest.addColumn("F3");
        tabel_trainingpbest.addColumn("F4");
        tabel_trainingpbest.addColumn("F5");
        tabel_trainingpbest.addColumn("F6");
        tabel_trainingpbest.addColumn("F7");
        tabel_trainingpbest.addColumn("f2");
        tabel_trainingpbest.addColumn("f1");
        tabel_trainingpbest.addColumn("fitness");

        tabel_prosestraining = new DefaultTableModel();
        tabel_proses_training.setModel(tabel_prosestraining);
        tabel_prosestraining.addColumn("Partikel");
        tabel_prosestraining.addColumn("λ");
        tabel_prosestraining.addColumn("C");
        tabel_prosestraining.addColumn("γ");
        tabel_prosestraining.addColumn("F1");
        tabel_prosestraining.addColumn("F2");
        tabel_prosestraining.addColumn("F3");
        tabel_prosestraining.addColumn("F4");
        tabel_prosestraining.addColumn("F5");
        tabel_prosestraining.addColumn("F6");
        tabel_prosestraining.addColumn("F7");
               
        //menampilkan tabel akurasi
        tabel_akurasi_gbest = new DefaultTableModel();
        tabel_akurasi.setModel(tabel_akurasi_gbest);
        tabel_akurasi_gbest.addColumn("Partikel");
        tabel_akurasi_gbest.addColumn("λ");
        tabel_akurasi_gbest.addColumn("C");
        tabel_akurasi_gbest.addColumn("γ");
        tabel_akurasi_gbest.addColumn("F1");
        tabel_akurasi_gbest.addColumn("F2");
        tabel_akurasi_gbest.addColumn("F3");
        tabel_akurasi_gbest.addColumn("F4");
        tabel_akurasi_gbest.addColumn("F5");
        tabel_akurasi_gbest.addColumn("F6");
        tabel_akurasi_gbest.addColumn("F7");
        tabel_akurasi_gbest.addColumn("f2");
        tabel_akurasi_gbest.addColumn("f1");
        tabel_akurasi_gbest.addColumn("fitness");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedDataset = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel6 = new javax.swing.JPanel();
        buttonLoadTraining = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_datatraining = new javax.swing.JTable();
        jComboBox2 = new javax.swing.JComboBox();
        jPanel8 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        cb_rasiodata = new javax.swing.JComboBox();
        btn_ambildatalatih = new javax.swing.JButton();
        btn_ambildatauji = new javax.swing.JButton();
        btn_hapuslatihuji = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jt_bB_lambda = new javax.swing.JTextField();
        jt_bA_lambda = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jt_bB_c = new javax.swing.JTextField();
        jt_bA_c = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jt_bB_gamma = new javax.swing.JTextField();
        jt_bA_gamma = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jml_iterasi_PSO = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jt_jml_individu = new javax.swing.JTextField();
        jPanel12 = new javax.swing.JPanel();
        jt_itermax_svm = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jt_epsilon = new javax.swing.JTextField();
        btn_process = new javax.swing.JButton();
        btn_hapus = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel16 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabel_training_xij = new javax.swing.JTable();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tabel_training_pbest = new javax.swing.JTable();
        jPanel18 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tabel_proses_training = new javax.swing.JTable();
        jPanel19 = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tabel_akurasi = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Penentuan Jenis Ikan Air Tawar Untuk Usaha Pembesaran Menggunakan Metode IEPSO-SVM");
        jLabel1.setToolTipText("");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedDataset.setToolTipText("");

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Keterangan Fitur"));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setText("F01 = Harga Benih\nF02 = Jumlah Pakan\nF03 = Jumlah Tebar Benih\nF04 = Permintaan Pasar\nF05 = Waktu Panen\nF06 = Jumlah Panen\nF07 = Harga Jual per kg\n");
        jScrollPane4.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jScrollPane4)
                .addContainerGap())
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Load Dataset"));

        buttonLoadTraining.setText("Load");
        buttonLoadTraining.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonLoadTrainingActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Dataset"));
        jPanel2.setAutoscrolls(true);

        tabel_datatraining.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Jenis Ikan", "F1", "F2", "F3", "F4", "F5", "F6", "F7"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tabel_datatraining.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(tabel_datatraining);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 895, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 472, Short.MAX_VALUE)
        );

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Dataset Ikan" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(buttonLoadTraining)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonLoadTraining)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jTabbedDataset.addTab("Dataset", jPanel3);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Rasio Data"));

        jLabel9.setText("Perbandingan Data");

        cb_rasiodata.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "90%:10%", "80%:20%", "70%:30%", "60%:40%", "50%:50%", "40%:60%", "30%:70%", "20%:80%", "10%:90%" }));
        cb_rasiodata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_rasiodataActionPerformed(evt);
            }
        });

        btn_ambildatalatih.setText("Ambil Data Latih");
        btn_ambildatalatih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ambildatalatihActionPerformed(evt);
            }
        });

        btn_ambildatauji.setText("Ambil Data Uji");
        btn_ambildatauji.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ambildataujiActionPerformed(evt);
            }
        });

        btn_hapuslatihuji.setText("Hapus Data");
        btn_hapuslatihuji.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapuslatihujiActionPerformed(evt);
            }
        });

        jButton2.setText("Save Log");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(29, 29, 29)
                        .addComponent(cb_rasiodata, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btn_hapuslatihuji, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_ambildatalatih, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_ambildatauji, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(cb_rasiodata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(btn_ambildatalatih, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_ambildatauji, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_hapuslatihuji, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2))
                .addContainerGap())
        );

        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder("Parameter Optimasi"));

        jLabel3.setText("Nilai  λ");

        jt_bB_lambda.setText("1");
        jt_bB_lambda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_bB_lambdaActionPerformed(evt);
            }
        });

        jt_bA_lambda.setText("10");
        jt_bA_lambda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_bA_lambdaActionPerformed(evt);
            }
        });

        jLabel4.setText("Nilai C ");

        jt_bB_c.setText("1");

        jt_bA_c.setText("1000");
        jt_bA_c.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_bA_cActionPerformed(evt);
            }
        });

        jLabel5.setText("Nilai γ");

        jt_bB_gamma.setText("0.5");

        jt_bA_gamma.setText("1");

        jLabel10.setText("Lower");

        jLabel11.setText("Upper");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jt_bB_c, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jt_bB_lambda, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jt_bB_gamma, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(jLabel10)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jt_bA_gamma, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                        .addComponent(jt_bA_lambda, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jt_bA_c, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(jLabel11))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jt_bB_lambda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jt_bA_lambda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jt_bB_c, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jt_bA_c, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jt_bB_gamma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jt_bA_gamma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Parameter PSO"));

        jLabel2.setText("Itermax PSO");

        jml_iterasi_PSO.setText("100");
        jml_iterasi_PSO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jml_iterasi_PSOActionPerformed(evt);
            }
        });

        jLabel7.setText("Jumlah Particle");

        jt_jml_individu.setText("7");
        jt_jml_individu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_jml_individuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jml_iterasi_PSO, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)
                    .addComponent(jt_jml_individu))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jml_iterasi_PSO))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jt_jml_individu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder("Parameter SVM"));

        jt_itermax_svm.setText("100");

        jLabel6.setText("Itermax SVM");

        jLabel8.setText("Nilai ε (Epsilon)");

        jt_epsilon.setText("0.01");
        jt_epsilon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_epsilonActionPerformed(evt);
            }
        });

        btn_process.setText("Training");
        btn_process.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_processActionPerformed(evt);
            }
        });

        btn_hapus.setText("Refresh");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(btn_process)))
                .addGap(37, 37, 37)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jt_itermax_svm, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jt_epsilon, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_hapus))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jt_itermax_svm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jt_epsilon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_process)
                    .addComponent(btn_hapus)))
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Proses Training"));

        jPanel16.setBorder(javax.swing.BorderFactory.createTitledBorder("Xij"));

        tabel_training_xij.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Idv", "λ", "C", "γ", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "F25", "f2", "f1", "f"
            }
        ));
        tabel_training_xij.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane3.setViewportView(tabel_training_xij);

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 837, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane2.addTab("Xij", jPanel16);

        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder("Pbest"));

        tabel_training_pbest.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Idv", "λ", "C", "γ", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "F25", "f2", "f1", "f"
            }
        ));
        tabel_training_pbest.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane8.setViewportView(tabel_training_pbest);

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 837, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane2.addTab("Pbest", jPanel17);

        jPanel18.setBorder(javax.swing.BorderFactory.createTitledBorder("Training"));

        tabel_proses_training.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Idv", "λ", "C", "γ", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "F25", "f2", "f1", "f"
            }
        ));
        tabel_proses_training.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane9.setViewportView(tabel_proses_training);

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 837, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 353, Short.MAX_VALUE)
        );

        jTabbedPane2.addTab("Training", jPanel18);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jTabbedPane2)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(134, Short.MAX_VALUE))
        );

        jTabbedDataset.addTab("Proses Training", jPanel8);

        jPanel19.setBorder(javax.swing.BorderFactory.createTitledBorder("Akurasi"));

        tabel_akurasi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Idv", "λ", "C", "γ", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "F25", "f2", "f1", "f"
            }
        ));
        tabel_akurasi.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane10.setViewportView(tabel_akurasi);

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 1161, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 548, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedDataset.addTab("Akurasi", jPanel19);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTabbedDataset, javax.swing.GroupLayout.PREFERRED_SIZE, 1200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedDataset, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        int training_xij = tabel_trainingxij.getRowCount();
        for (int i = 0; i < training_xij; i++) {
            ((DefaultTableModel)tabel_training_xij.getModel()).removeRow(0);
        }
        int training_pbest = tabel_trainingpbest.getRowCount();
        for (int i = 0; i < training_pbest; i++) {
            ((DefaultTableModel)tabel_training_pbest.getModel()).removeRow(0);
        }
        int training_pso = tabel_prosestraining.getRowCount();
        for (int i = 0; i < training_pso; i++) {
            ((DefaultTableModel)tabel_proses_training.getModel()).removeRow(0);
        }
        int training_akurasi= tabel_akurasi_gbest.getRowCount();
        for (int i = 0; i < training_akurasi; i++) {
            ((DefaultTableModel)tabel_akurasi.getModel()).removeRow(0);
        }
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void btn_processActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_processActionPerformed
        int itermax_PSO = Integer.parseInt(jml_iterasi_PSO.getText()) + 1;
        int individu = Integer.parseInt(jt_jml_individu.getText());
        int bb_lambda = Integer.parseInt(jt_bB_lambda.getText());
        int ba_lambda = Integer.parseInt(jt_bA_lambda.getText());
        int bb_c = Integer.parseInt(jt_bB_c.getText());
        int ba_c = Integer.parseInt(jt_bA_c.getText());
        double bb_gamma = Double.parseDouble(jt_bB_gamma.getText());
        double ba_gamma = Double.parseDouble(jt_bA_gamma.getText());
        pso pso = new pso(itermax_PSO, individu, ba_lambda, bb_lambda, bb_c, ba_c, bb_gamma, ba_gamma);
        String perhitunganSvm = "";
        //Menampilkan Xij
        for (int t = 0; t < itermax_PSO; t++) {
            double[][] encodeXij = new double[individu][11];
            encodeXij = pso.getXij(t);
            Object[] fitur = new Object[14];
            fitur[0] = "Xij Iterasi " + t;
            tabel_trainingxij.addRow(fitur);
            for (int i = 0; i < individu; i++) {
                Object[] o = new Object[14];
                o[0] = Integer.toString(i + 1);//convert
                o[1] = numformat1.format(pso.getLamda(t)[i]);
                o[2] = numformat2.format(pso.getC(t)[i]);
                o[3] = numformat.format(pso.getGamma(t)[i]);
                o[11] = numformat.format(pso.getf2(t)[i]);
                o[12] = numformat.format(pso.getf1(t)[i]);
                o[13] = numformat.format(pso.getf(t)[i]);
                for (int j = 4; j < 11; j++) {
                    o[j] = Integer.toString((int) encodeXij[i][j - 4]);//convert
                }
                tabel_trainingxij.addRow(o);
            }
            double[] encodeGbest = new double[11];
            encodeGbest = pso.getGbest_Xij(t);
            fitur[0] = "Gbest " + t;
            tabel_trainingxij.addRow(fitur);

            Object[] o = new Object[14];
            o[0] = Integer.toString(pso.getIndex_Gbest(t) + 1);//convert
            o[1] = numformat1.format(pso.getLamda(t)[pso.getIndex_Gbest(t)]);
            o[2] = numformat2.format(pso.getC(t)[pso.getIndex_Gbest(t)]);
            o[3] = numformat.format(pso.getGamma(t)[pso.getIndex_Gbest(t)]);
            o[11] = numformat.format(pso.getf2(t)[pso.getIndex_Gbest(t)]);
            o[12] = numformat.format(pso.getf1(t)[pso.getIndex_Gbest(t)]);
            o[13] = numformat.format(pso.getf(t)[pso.getIndex_Gbest(t)]);
            for (int j = 4; j < 11; j++) {
                o[j] = Integer.toString((int) encodeGbest[j - 4]);//convert
            }
            tabel_trainingxij.addRow(o);

        }
        //Menampilkan pbest
        for (int t = 0; t < itermax_PSO; t++) {
            double[][] encodepbest = new double[individu][11];
            encodepbest = pso.getPbest(t);
            Object[] fitur = new Object[14];
            fitur[0] = "Pbest Iterasi " + t;
            tabel_trainingpbest.addRow(fitur);
            for (int i = 0; i < individu; i++) {
                Object[] o = new Object[14];

                o[0] = Integer.toString(i + 1);
                o[1] = numformat1.format(pso.getLamda_pbest(t)[i]);
                o[2] = numformat2.format(pso.getC_pbest(t)[i]);
                o[3] = numformat.format(pso.getGamma_pbest(t)[i]);
                o[11] = numformat.format(pso.getf2_pbest(t)[i]);
                o[12] = numformat.format(pso.getf1_pbest(t)[i]);
                o[13] = numformat.format(pso.getf_pbest(t)[i]);
                for (int j = 4; j < 11; j++) {
                    o[j] = Integer.toString((int) encodepbest[i][j - 4]);
                }
                tabel_trainingpbest.addRow(o);
            }
            double[] encodeGbest_pbest = new double[11];
            encodeGbest_pbest = pso.getGbest_pbest(t);
            fitur[0] = "Gbest Iterasi " + t;
            tabel_trainingpbest.addRow(fitur);

            Object[] o = new Object[14];
            o[0] = Integer.toString(pso.getIndex_Gbest(t) + 1);
            o[1] = numformat1.format(pso.getLamda_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[2] = numformat2.format(pso.getC_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[3] = numformat.format(pso.getGamma_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[11] = numformat.format(pso.getf2_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[12] = numformat.format(pso.getf1_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[13] = numformat.format(pso.getf_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
//            System.out.println("gbest pbest "+pso.getIndex_Gbest_pbest(t));
            for (int j = 4; j < 11; j++) {
                o[j] = Integer.toString((int) encodeGbest_pbest[j - 4]);
            }
            tabel_trainingpbest.addRow(o);
        }

        for (int t = 1; t < itermax_PSO; t++) {
            //variable
            double[][] encodetraining_velocity = new double[individu][11];
            double[][] encodetraining_sigmoid = new double[individu][11];
            double[][] encodetraining_random = new double[individu][11];
            double[][] encodetraining_xij = new double[individu][11];

            //Proses memanggil method pada class pso
            encodetraining_velocity = pso.getVelocity(t);
            encodetraining_sigmoid = pso.getSigmoid(t);
            encodetraining_random = pso.getRandom(t);
            encodetraining_xij = pso.getXij(t);

            //inisialisasi
            Object[] fitur_velocity = new Object[14];
            Object[] fitur_sigmoid = new Object[14];
            Object[] fitur_random = new Object[14];
            Object[] fitur_xij = new Object[14];

            //untuk menampilkan velocity
            fitur_velocity[0] = "Velocity Iterasi " + t;
            tabel_prosestraining.addRow(fitur_velocity);
            for (int i = 0; i < individu; i++) {
                Object[] o = new Object[14];
                o[0] = Integer.toString(i + 1);
                o[1] = numformat1.format(pso.getLamda(t)[i]);
                o[2] = numformat2.format(pso.getC(t)[i]);
                o[3] = numformat.format(pso.getGamma(t)[i]);
                for (int j = 4; j < 11; j++) {
                    o[j] = numformat.format((double) encodetraining_velocity[i][j - 4]);
                }
                tabel_prosestraining.addRow(o);
            }

            //untuk menampilkan sigmoid
            fitur_sigmoid[0] = "Sigmoid Iterasi " + t;
            tabel_prosestraining.addRow(fitur_sigmoid);
            for (int i = 0; i < individu; i++) {
                Object[] o = new Object[14];
                o[0] = Integer.toString(i + 1);
                o[1] = numformat1.format(pso.getLamda(t)[i]);
                o[2] = numformat2.format(pso.getC(t)[i]);
                o[3] = numformat.format(pso.getGamma(t)[i]);
                for (int j = 4; j < 11; j++) {
                    o[j] = numformat.format((double) encodetraining_sigmoid[i][j - 4]);
                }
                tabel_prosestraining.addRow(o);
            }

            //untuk menampilkan random
            fitur_random[0] = "Random Iterasi " + t;
            tabel_prosestraining.addRow(fitur_random);
            for (int i = 0; i < individu; i++) {
                Object[] o = new Object[14];
                o[0] = Integer.toString(i + 1);
                o[1] = numformat1.format(pso.getLamda(t)[i]);
                o[2] = numformat2.format(pso.getC(t)[i]);
                o[3] = numformat.format(pso.getGamma(t)[i]);
                for (int j = 4; j < 11; j++) {
                    o[j] = numformat.format((double) encodetraining_random[i][j - 4]);
                }
                tabel_prosestraining.addRow(o);
            }

            //untuk menampilkan xij
            fitur_xij[0] = "Xij Iterasi " + t;
            tabel_prosestraining.addRow(fitur_xij);
            for (int i = 0; i < individu; i++) {
                Object[] o = new Object[14];
                o[0] = Integer.toString(i + 1);
                o[1] = numformat1.format(pso.getLamda(t)[i]);
                o[2] = numformat2.format(pso.getC(t)[i]);
                o[3] = numformat.format(pso.getGamma(t)[i]);
                for (int j = 4; j < 11; j++) {
                    o[j] = Integer.toString((int) encodetraining_xij[i][j - 4]);
                }
                tabel_prosestraining.addRow(o);
            }
           
            double[] encodeGbest_pbest = new double[11];
            encodeGbest_pbest = pso.getGbest_Xij(t);
            Object[] fitur = new Object[14];
            fitur[0] = "Gbest Iterasi " + t;
            tabel_akurasi_gbest.addRow(fitur);

            Object[] o = new Object[14];
            o[0] = Integer.toString(pso.getIndex_Gbest(t) + 1);
            o[1] = numformat1.format(pso.getLamda_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[2] = numformat2.format(pso.getC_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[3] = numformat.format(pso.getGamma_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[11] = numformat.format(pso.getf2(t)[pso.getIndex_Gbest_pbest(t)]);
            o[12] = numformat.format(pso.getf1_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            o[13] = numformat.format(pso.getf_pbest(t)[pso.getIndex_Gbest_pbest(t)]);
            for (int j = 4; j < 11; j++) {
                o[j] = Integer.toString((int) encodeGbest_pbest[j - 4]);
            }
            tabel_akurasi_gbest.addRow(o);
        }

    }//GEN-LAST:event_btn_processActionPerformed

    private void jt_epsilonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_epsilonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_epsilonActionPerformed

    private void jt_jml_individuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_jml_individuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_jml_individuActionPerformed

    private void jml_iterasi_PSOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jml_iterasi_PSOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jml_iterasi_PSOActionPerformed

    private void jt_bA_cActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_bA_cActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_bA_cActionPerformed

    private void jt_bA_lambdaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_bA_lambdaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_bA_lambdaActionPerformed

    private void btn_hapuslatihujiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapuslatihujiActionPerformed
        // TODO add your handling code here:
        svm.hapusData();
    }//GEN-LAST:event_btn_hapuslatihujiActionPerformed

    private void btn_ambildataujiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ambildataujiActionPerformed
        svm.get_datauji();
        //        String combobox_rasiodata = cb_rasiodata.getSelectedItem().toString();
        //        if (combobox_rasiodata.equals("90%:10%")) {
            //            svm.get_datauji();
            //
            //
            //        }
    }//GEN-LAST:event_btn_ambildataujiActionPerformed

    private void btn_ambildatalatihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ambildatalatihActionPerformed

        String combobox_rasiodata = cb_rasiodata.getSelectedItem().toString();
        try{
            Connection c = (Connection) KoneksiDatabase.getKoneksi();
            Statement s = c.createStatement();
            String sql = "select * from dataset_konversi";
            ResultSet r = s.executeQuery(sql);
            r.last();
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Gagal Koneksi" + e);
        }

        if (combobox_rasiodata.equals("90%:10%")) {
            double var_data1 = 0.3 * 90;
            double var_data2 = 0.3 * 90;
            double var_data3 = 0.3 * 90;

            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;

        }
        if (combobox_rasiodata.equals("80%:20%")){
            double var_data1 = 0.3 * 80;
            double var_data2 = 0.3 * 80;
            double var_data3 = 0.3 * 80;

            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;
        }
        if (combobox_rasiodata.equals("70%:30%")){
            double var_data1 = 0.3 * 70;
            double var_data2 = 0.3 * 70;
            double var_data3 = 0.3 * 70;

            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;
        }
        if (combobox_rasiodata.equals("60%:40%")){
            double var_data1 = 0.3 * 60;
            double var_data2 = 0.3 * 60;
            double var_data3 = 0.3 * 60;

            System.out.println("data 1 = "+var_data1);
            System.out.println("data 2 = "+var_data2);
            System.out.println("data 3 = "+var_data3);
            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;
        }
        if (combobox_rasiodata.equals("50%:50%")){
            double var_data1 = 0.3 * 50;
            double var_data2 = 0.3 * 50;
            double var_data3 = 0.3 * 50;

            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;
        }
        if (combobox_rasiodata.equals("40%:60%")){
            double var_data1 = 0.3 * 40;
            double var_data2 = 0.3 * 40;
            double var_data3 = 0.3 * 40;

            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;
        }
        if (combobox_rasiodata.equals("30%:70%")){
            double var_data1 = 0.3 * 30;
            double var_data2 = 0.3 * 30;
            double var_data3 = 0.3 * 30;

            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;
        }
        if (combobox_rasiodata.equals("20%:80%")){
            double var_data1 = 0.3 * 20;
            double var_data2 = 0.3 * 20;
            double var_data3 = 0.3 * 20;

            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;
        }
        if (combobox_rasiodata.equals("10%:90%")){
            double var_data1 = 0.3 * 10;
            double var_data2 = 0.3 * 10;
            double var_data3 = 0.3 * 10;

            svm.getDataset_real_angka("layak", String.valueOf(var_data1).replaceAll(".0",""));
            svm.getDataset_real_angka("kuranglayak", String.valueOf(var_data2).replaceAll(".0",""));
            svm.getDataset_real_angka("tidaklayak", String.valueOf(var_data3).replaceAll(".0",""));;
        }
    }//GEN-LAST:event_btn_ambildatalatihActionPerformed

    private void cb_rasiodataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_rasiodataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_rasiodataActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void buttonLoadTrainingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonLoadTrainingActionPerformed
        if (jComboBox2.getSelectedItem() == "Dataset Ikan") {
            tabel_datasetreal.getDataVector().removeAllElements();
            tabel_datasetreal.fireTableDataChanged();
            try {
                Connection c = (Connection) KoneksiDatabase.getKoneksi();
                Statement s = c.createStatement();
                String sql = "select * from dataset_asli";
                ResultSet r = s.executeQuery(sql);

                while (r.next()) {
                    Object[] o = new Object[11];
                    o[0] = r.getString("Id");
                    o[1] = r.getString("Nim");
                    o[2] = r.getString("F1");
                    o[3] = r.getString("F2");
                    o[4] = r.getString("F3");
                    o[5] = r.getString("F4");
                    o[6] = r.getString("F5");
                    o[7] = r.getString("F6");
                    o[8] = r.getString("F7");
                    o[9] = r.getString("Actual");
                    o[10] = r.getString("Kelas_Y");
                    tabel_datasetreal.addRow(o);
                }
                r.close();
                s.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Gagal Koneksi" + e);
            }

        }
    }//GEN-LAST:event_buttonLoadTrainingActionPerformed
    public void saveXij(){
        BufferedWriter bfw = null;
        try {
            bfw = new BufferedWriter(new FileWriter("D:\\Xij.txt"));
            for (int i = 0; i < tabel_training_xij.getColumnCount(); i++) {
                bfw.write(tabel_training_xij.getColumnName(i));
                bfw.write("\t");
            }
            System.out.println("jumlah baris : "+(String)tabel_training_xij.getValueAt(0, 1));
            for (int i = 0; i < tabel_training_xij.getRowCount(); i++) {
            bfw.newLine();
                
            for (int j = 0; j < tabel_training_xij.getColumnCount(); j++) {
                if(tabel_training_xij.getValueAt(i, j) == null){
                    bfw.write("");
                }
                else{
                    bfw.write((String) (tabel_training_xij.getValueAt(i, j)));
                }
                bfw.write("\t");
            }
        }   bfw.close();
        } catch (IOException ex) {
            Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                bfw.close();
            } catch (IOException ex) {
                Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void savePbest(){
        BufferedWriter bfw = null;
        try {
            bfw = new BufferedWriter(new FileWriter("D:\\Pbest.txt"));
            for (int i = 0; i < tabel_training_pbest.getColumnCount(); i++) {
                bfw.write(tabel_training_pbest.getColumnName(i));
                bfw.write("\t");
            }
            System.out.println("jumlah baris : "+(String)tabel_training_pbest.getValueAt(0, 1));
            for (int i = 0; i < tabel_training_pbest.getRowCount(); i++) {
            bfw.newLine();
                
            for (int j = 0; j < tabel_training_pbest.getColumnCount(); j++) {
                if(tabel_training_pbest.getValueAt(i, j) == null){
                    bfw.write("");
                }
                else{
                    bfw.write((String) (tabel_training_pbest.getValueAt(i, j)));
                }
                bfw.write("\t");
            }
        }   bfw.close();
        } catch (IOException ex) {
            Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                bfw.close();
            } catch (IOException ex) {
                Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
        public void saveTraining(){
        BufferedWriter bfw = null;
        try {
            bfw = new BufferedWriter(new FileWriter("D:\\Prosestraining.txt"));
            for (int i = 0; i < tabel_proses_training.getColumnCount(); i++) {
                bfw.write(tabel_proses_training.getColumnName(i));
                bfw.write("\t");
            }
            System.out.println("jumlah baris : "+(String)tabel_proses_training.getValueAt(0, 1));
            for (int i = 0; i < tabel_proses_training.getRowCount(); i++) {
            bfw.newLine();
                
            for (int j = 0; j < tabel_proses_training.getColumnCount(); j++) {
                if(tabel_proses_training.getValueAt(i, j) == null){
                    bfw.write("");
                }
                else{
                    bfw.write((String) (tabel_proses_training.getValueAt(i, j)));
                }
                bfw.write("\t");
            }
        }   bfw.close();
        } catch (IOException ex) {
            Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                bfw.close();
            } catch (IOException ex) {
                Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void saveAkurasi(){
        BufferedWriter bfw = null;
        try {
            bfw = new BufferedWriter(new FileWriter("D:\\Akurasi.txt"));
            for (int i = 0; i < tabel_akurasi.getColumnCount(); i++) {
                bfw.write(tabel_akurasi.getColumnName(i));
                bfw.write("\t");
            }
            System.out.println("jumlah baris : "+(String)tabel_akurasi.getValueAt(0, 1));
            for (int i = 0; i < tabel_akurasi.getRowCount(); i++) {
            bfw.newLine();
                
            for (int j = 0; j < tabel_akurasi.getColumnCount(); j++) {
                if(tabel_akurasi.getValueAt(i, j) == null){
                    bfw.write("");
                }
                else{
                    bfw.write((String) (tabel_akurasi.getValueAt(i, j)));
                }
                bfw.write("\t");
            }
        }   bfw.close();
        } catch (IOException ex) {
            Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                bfw.close();
            } catch (IOException ex) {
                Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        saveXij();
        savePbest();
        saveTraining();
        saveAkurasi();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jt_bB_lambdaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_bB_lambdaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_bB_lambdaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton btn_ambildatalatih;
    private javax.swing.JButton btn_ambildatauji;
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_hapuslatihuji;
    public static javax.swing.JButton btn_process;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton buttonLoadTraining;
    public static javax.swing.JComboBox cb_rasiodata;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedDataset;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTextArea jTextArea1;
    public static javax.swing.JTextField jml_iterasi_PSO;
    private javax.swing.JTextField jt_bA_c;
    private javax.swing.JTextField jt_bA_gamma;
    private javax.swing.JTextField jt_bA_lambda;
    private javax.swing.JTextField jt_bB_c;
    private javax.swing.JTextField jt_bB_gamma;
    private javax.swing.JTextField jt_bB_lambda;
    public static javax.swing.JTextField jt_epsilon;
    public static javax.swing.JTextField jt_itermax_svm;
    public static javax.swing.JTextField jt_jml_individu;
    private javax.swing.JTable tabel_akurasi;
    public static javax.swing.JTable tabel_datatraining;
    private javax.swing.JTable tabel_proses_training;
    private javax.swing.JTable tabel_training_pbest;
    private javax.swing.JTable tabel_training_xij;
    // End of variables declaration//GEN-END:variables
}
