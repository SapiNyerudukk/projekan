package klasifikasi;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.Random;

/**
 *
 * @author Adzhana
 */
public class pso {

    static String perhitunganSvm = "";
    private static double Xij[][][];
    static double velocity[][][];
    static double sigmoid[][][];
    static double rnd[][][];

    static double Pbest[][][];
    static double[][] Gbest_Xij;
    static double[][] Gbest_pbest;
    static double f[][], f1[][], f2[][];
    static double f_pbest[][], f1_pbest[][], f2_pbest[][];

    //Inisialisasi awal
    static int jml_fitur = 7;
    static double tmax = 2;
    static double wmax = 0.9, r1 = 0.5, c1f = 0.5, r2 = 0.5, c1i = 2.5, c2f = 2.5, wmin = 0.4, c2i = 0.5, alpha = 0.85, beta = 0.15;
    //Batas interval Xij
    int cMax = 100, cMin = 1;
    double lambdaMax = 0.01, lambdaMin = 0.00001, gammaMax = 0.9, gammaMin = 0.1;
    //Batas interval Vij
    double lambdaMaxV, lambdaMinV, cMaxV, cMinV, gammaMaxV, gammaMinV, vMin = -6, vMax = 6;
    //parameter PSO
    static double w[], c1[], c2[];
    //parameter SVM
    static double lambdaIn[], cIn[], gammaIn[];
    static double lambda[][], C[][], gamma[][];
    static double lambda_pbest[][], C_pbest[][], gamma_pbest[][];

    static int index_gbest[];
    static int index_gbest_pbest[];

    static double temp = 0;
    static double temp_pbest = 0;
    private static DecimalFormat numformat;


    public pso(int itermax, int jml_individu, int bB_lambda, int bA_lambda, int bB_c, int bA_c, double bB_gamma, double bA_gamma) {
        numformat = new DecimalFormat("0.00");
        rnd = new double[itermax][jml_individu][jml_fitur];
        Xij = new double[itermax][jml_individu][jml_fitur];
        Random ran = new Random();

        lambdaIn = new double[jml_individu];
        cIn = new double[jml_individu];
        gammaIn = new double[jml_individu];

        //fungsi untuk menginisialisasi Xij Awal
        for (int i = 0; i < jml_individu; i++) {
            for (int j = 0; j < jml_fitur; j++) {
                if ( j == 7) {
                    Xij[0][i][j] = 1;
                } else {
                    Xij[0][i][j] = (int) (Math.random() * 2);
                }
            }
            //fungsi untuk membangkitkan parameter svm
            lambdaIn[i] = bB_lambda + (bA_lambda - bB_lambda) * ran.nextDouble();
            cIn[i] = bB_c + (bA_c - bB_c) * ran.nextDouble();
            gammaIn[i] = bB_gamma + (bA_gamma - bB_gamma) * ran.nextDouble();
        }

        f1 = new double[itermax][jml_individu];
        f2 = new double[itermax][jml_individu];
        f = new double[itermax][jml_individu];
        f1_pbest = new double[itermax][jml_individu];
        f2_pbest = new double[itermax][jml_individu];
        f_pbest = new double[itermax][jml_individu];
        Pbest = new double[itermax][jml_individu][jml_fitur];
        Gbest_Xij = new double[itermax][jml_fitur];
        Gbest_pbest = new double[itermax][jml_fitur];
        index_gbest = new int[itermax];
        index_gbest_pbest = new int[itermax];

        w = new double[itermax];
        c1 = new double[itermax];
        c2 = new double[itermax];

        velocity = new double[itermax][jml_individu][jml_fitur];
        sigmoid = new double[itermax][jml_individu][jml_fitur];
        //rnd= new double [itermax][jml_individu][jml_fitur];
        lambda = new double[itermax][jml_individu];
        C = new double[itermax][jml_individu];
        gamma = new double[itermax][jml_individu];
        lambda_pbest = new double[itermax][jml_individu];
        C_pbest = new double[itermax][jml_individu];
        gamma_pbest = new double[itermax][jml_individu];
        
        for (int t = 0; t < itermax; t++) {
            for (int i = 0; i < jml_individu; i++) {
                if (t == 0) {
                    lambda[t][i] = lambdaMin + lambdaIn[i] * (lambdaMax - lambdaMin);
                    C[t][i] = cMin + cIn[i] * (cMax - cMin);
                    gamma[t][i] = gammaMin + gammaIn[i] * (gammaMax - gammaMin);
                } else {
                    lambda[t][i] = lambda[0][i];
//                            getParameterSvm(lambda[0][i], lambdaMin, lambdaMax);
                    C[t][i] = C[0][i];
//                            getParameterSvm(C[0][i], cMin, cMax);
                    gamma[t][i] = gamma[0][i];
//                            getParameterSvm(gamma[0][i], gammaMin, gammaMax);
                    w[t] = wmin + (wmax - wmin) * ((itermax - t) / itermax);
                    c1[t] = (c1f - c1i) * (t / itermax) + c1i;
                    c2[t] = (c2f - c2i) * (t / itermax) + c2i;
                    //fungsi menghitung velocity
                    for (int j = 0; j < jml_fitur; j++) {
                        velocity[t][i][j] = w[t] * velocity[t - 1][i][j] + c1[t] * r1 * (Pbest[t - 1][i][j] - Xij[t - 1][i][j]) + c2[t] * r2 * (Gbest_pbest[t - 1][j] - Xij[t - 1][i][j]);
                    }
                    //fungsi menghitung sigmoid
                    for (int j = 0; j < jml_fitur; j++) {
                        sigmoid[t][i][j] = 1 / (1 + Math.exp(-velocity[t][i][j]));
                    }
                    //fungsi menentukan nilai random
                    for (int j = 0; j < jml_fitur; j++) {
                        rnd[t][i][j] = Math.abs(Math.random());
                    }

                    //Fungsi untuk mendapatkan Xij iterasi baru
                    for (int j = 0; j < jml_fitur; j++) {
                        if (rnd[t][i][j] < sigmoid[t][i][j]) {
                            Xij[t][i][j] = 1;
                        } else if (rnd[t][i][j] >= sigmoid[t][i][j]) {
                            Xij[t][i][j] = 0;
                        }
                    }
//                    setFitness(t);

                }
            }
            setFitness(t, jml_individu, jml_fitur);
        }

    }

    public double getParameterSvm(double a, double b, double c) {
        double abc = 0;
        if (a >= b && a <= c) {
            return a;
        } else if (a < b) {
            return b;
        } else if (a > c) {
            return c;
        }
        return abc;

    }

    public static void main(String[] args) {
        int itermax = 3, jml_individu = 10;
        pso pso = new pso(itermax, jml_individu, 0, 1, 0, 1, 0, 1);
//        svm svm = new svm();
//        for (int i = 0; i < itermax; i++) {
//            for (int j = 0; j < 3; j++) {
//                f1[i][j] = svm.hitunganSvm(lambdaIn[j], cIn[j], gammaIn[j], Xij[0][j]);
//            }
//        }

        for (int t = 0; t < itermax; t++) {
            System.out.println("Xij " + t);
            for (int i = 0; i < jml_individu; i++) {
                System.out.print(lambda[t][i] + " " + C[t][i] + " " + numformat.format(gamma[t][i]) + " ");
                for (int j = 0; j < jml_fitur; j++) {

                    System.out.print((int) Xij[t][i][j] + " ");
                }
                System.out.print(numformat.format(f2[t][i]) + " " + numformat.format(f1[t][i]) + " " + numformat.format(f[t][i]));
                System.out.println("");

            }
            System.out.println("");

            System.out.println("Pbest " + t);
            for (int i = 0; i < jml_individu; i++) {
                System.out.print(lambda[t][i] + " " + C[t][i] + " " + numformat.format(gamma[t][i]) + " ");
                for (int j = 0; j < jml_fitur; j++) {
                    System.out.print((int) Pbest[t][i][j] + " ");
                }
                System.out.print(numformat.format(f2[t][i]) + " " + numformat.format(f1[t][i]) + " " + numformat.format(f[t][i]));
                System.out.println("");
            }
            System.out.println("");
            System.out.println("Gbest " + t);
            System.out.print(lambda[t][index_gbest[t]] + " " + C[t][index_gbest[t]] + " " + numformat.format(gamma[t][index_gbest[t]]) + " ");
            for (int j = 0; j < jml_fitur; j++) {
                System.out.print((int) Gbest_Xij[t][j] + " ");
            }
            System.out.print(numformat.format(f2[t][index_gbest[t]]) + " " + numformat.format(f1[t][index_gbest[t]]) + " " + numformat.format(f[t][index_gbest[t]]));
            System.out.println("");
            System.out.println("");
            System.out.println("Velocity " + t);
            for (int i = 0; i < jml_individu; i++) {
                if (t != 0) {
                    System.out.print(lambda[t][i] + " " + C[t][i] + " " + numformat.format(gamma[t][i]) + " ");
                } else {
                    System.out.print(0 + " " + 0 + " " + 0 + " ");
                }

                for (int j = 0; j < jml_fitur; j++) {
                    if (t != 0) {
                        System.out.print(numformat.format(velocity[t][i][j]) + " ");
                    } else {
                        System.out.print(((int) velocity[t][i][j]) + " ");
                    }

                }
                System.out.println("");
            }
            System.out.println("");
            if (t != 0) {
                System.out.println("Sigmoid " + t);
                for (int i = 0; i < jml_individu; i++) {
                    for (int j = 0; j < jml_fitur; j++) {
                        System.out.print(numformat.format(sigmoid[t][i][j]) + " ");
                    }
                    System.out.println("");
                }
                System.out.println("");
            }
            System.out.println("");
            if (t != 0) {
                System.out.println("Random " + t);
                for (int i = 0; i < jml_individu; i++) {
                    for (int j = 0; j < jml_fitur; j++) {

                        System.out.print(numformat.format(rnd[t][i][j]) + " ");
//                        System.out.print(numformat.format(rnd[t - 1][i][j]) + " ");
                    }
                    System.out.println("");
                }
                System.out.println("");
            }
        }

    }

    public double[][] getXij(int itermax) {
        return Xij[itermax];
    }

    public double[][] getPbest(int itermax) {
        return Pbest[itermax];
    }

    public double[] getGbest_Xij(int itermax) {
        return Gbest_Xij[itermax];
    }
    public double[] getGbest_pbest(int itermax){
        return Gbest_pbest[itermax];
    }

    public int getIndex_Gbest(int itermax) {
        return index_gbest[itermax];
    }
        public int getIndex_Gbest_pbest(int itermax) {
        return index_gbest_pbest[itermax];
    }

    //memanggil method velocity
    public double[][] getVelocity(int itermax) {
        return velocity[itermax];
    }

    //memanggil method sigmoid
    public double[][] getSigmoid(int itermax) {
        return sigmoid[itermax];
    }

    //memanggil method random
    public double[][] getRandom(int itermax) {
        return rnd[itermax];
    }

    public double[] getLamda(int itermax) {
        return lambda[itermax];
    }

    public double[] getC(int itermax) {
        return C[itermax];
    }

    public double[] getGamma(int itermax) {
        return gamma[itermax];
    }

    public double[] getf2(int itermax) {
        return f2[itermax];
    }

    public double[] getf1(int itermax) {
        return f1[itermax];
    }

    public double[] getf(int itermax) {
        return f[itermax];
    }

    public double[] getLamda_pbest(int itermax) {
        return lambda_pbest[itermax];
    }

    public double[] getC_pbest(int itermax) {
        return C_pbest[itermax];
    }

    public double[] getGamma_pbest(int itermax) {
        return gamma_pbest[itermax];
    }

    public double[] getf2_pbest(int itermax) {
        return f2_pbest[itermax];
    }

    public double[] getf1_pbest(int itermax) {
        return f1_pbest[itermax];
    }

    public double[] getf_pbest(int itermax) {
        return f_pbest[itermax];
    }

    public String getPerhitunganSvm() {
        return perhitunganSvm;
    }

    public static void setFitness(int t, int jml_individu, int jml_fitur) {

        svm svm = new svm();

        for (int i = 0; i < jml_individu; i++) {
            f1[t][i] = svm.hitunganSvm(lambda[t][i], C[t][i], gamma[t][i], Xij[t][i], t, i);
            perhitunganSvm = perhitunganSvm + svm.getPerhitunganSvm();
            double sum = 0;
            for (int j = 0; j < jml_fitur; j++) {
                sum = sum + Xij[t][i][j];
            }
            f2[t][i] = 1 - (sum) / jml_fitur;
            f[t][i] = alpha * f1[t][i] + beta * f2[t][i];
            //set gbest xij
            if (i == 0) {
                Gbest_Xij[t] = Xij[t][i];
                temp = f[t][i];
                index_gbest[t] = i;
            } else {
                if (temp < f[t][i]) {
                    Gbest_Xij[t] = Xij[t][i];
                    temp = f[t][i];
                    index_gbest[t] = i;
                }
            }
        }
        if (t == 0) {
            Pbest[t] = Xij[0];
            lambda_pbest[t] = lambda[0];
            C_pbest[t] = C[0];
            gamma_pbest[t] = gamma[0];
            f_pbest[t] = f[0];
            f2_pbest[t] = f2[0];
            f1_pbest[t] = f1[0];
        } else {
//          fungsi membandingkan pbest iterasi baru
            if (f[t][index_gbest[t]] > f_pbest[t - 1][index_gbest_pbest[t - 1]]) {
                Pbest[t] = Xij[t];
                lambda_pbest[t] = lambda[t];
                C_pbest[t] = C[t];
                gamma_pbest[t] = gamma[t];
                f_pbest[t] = f[t];
                f2_pbest[t] = f2[t];
                f1_pbest[t] = f1[t];
            } else {
                Pbest[t] = Pbest[t - 1];
                lambda_pbest[t] = lambda_pbest[t - 1];
                C_pbest[t] = C_pbest[t - 1];
                gamma_pbest[t] = gamma_pbest[t - 1];
                f_pbest[t] = f_pbest[t - 1];
                f2_pbest[t] = f2_pbest[t - 1];
                f1_pbest[t] = f1_pbest[t - 1];
            }
        }
        //set gbest pbest
        for (int i = 0; i < jml_individu; i++) {
            if (i == 0||temp_pbest<f_pbest[t][i]) {
                temp_pbest = f_pbest[t][i];
                index_gbest_pbest[t] = i;
            }
            //gbest pbest
            Gbest_pbest[t]=Pbest[t][index_gbest_pbest[t]];
        }

    }

}
