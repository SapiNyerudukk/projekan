package klasifikasi;

import java.text.DecimalFormat;
import com.mysql.jdbc.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import koneksidatabase.KoneksiDatabase;

/**
 *
 * @author Adzhana
 */
public class svm {

    Connection c = null;
    Statement s = null;
    ResultSet r = null;

    String view_kernelrbf = "";
    int jml_datatraining, jml_datauji, jml_datatraining_2, jml_datauji_2, jml_satu, jml_minsatu;
    double[][] fitur_datatraining, fitur_datauji, fitur_datatraining_2, fitur_datauji_2;
    double lambdaMin = 0.00001, lambdaMax = 0.01, cMin = 1, cMax = 100, gammaMin = 0.1, gammaMax = 0.9, gamma;

    //input parameter
    double lambdaIn[], cIn[], gammaIn[];
    //Variabel training SVM
    double sigma = 1, kernelRbf[][], kernelRbf_2[][], matrixhessian[][], matrixhessian_2[][], error_rate[][][], epsilon = 0.0, error_rate_2[][][], delta_alphai[][], delta_alphai_2[][], sigma_error[][], sigma_error_2[][], sigma_wxplus, sigma_wxmin, sigma_wxplus_2, sigma_wxmin_2;

    //Inisialisasi iterasi 0
    double alphai[][], alphai_2[][];
    //mencari nilai maks
    double maxplus, maxmin, maxplus_2, maxmin_2;
    //mencari nilai w.x+ & w.x-
    double wxplus[], wxmin[], wxplus_2[], wxmin_2[];
    double nilai_b, nilai_b_2;
//    int jml_iterasi = 3;
    //menghitung datauji
    double kernelRbf_datauji[][], kernelRbf_datauji_2[][];
    double kernelPolynomial_datauji[][], kernelPolynomial_datauji_2[][];
    double fx[][], sigma_fx[], fx_2[][], sigma_fx_2[];
    //menghitung nilai fx dan fungsi klasifikasi
    double nilai_fx[], nilai_fx_2[];
    double fungsi_klasifikasi[], fungsi_klasifikasi_2[];
    //perhitungan fx dan confusion matrix
    Object perhitungan_fx[][];
    double confusion_matrix[][];
    //nilai akurasi
    double tp, tn, fp, fn, akurasi;

    double[][] dataTraining(int fitur[]) {

        return fitur_datatraining;
    }
    private DecimalFormat numformat;
    private DecimalFormat numformat1;
    private DecimalFormat numformat2;

    //method untuk memanggil jumlah data berprestasi, sedang, kritis
    public static int getKriteria(String actual) {
        int status = 0;
        try {
            Connection c = (Connection) KoneksiDatabase.getKoneksi();
            Statement s = c.createStatement();
            String sql = "select count(*)as jml_satu from data_training where Actual = '" + actual + "'";
            ResultSet r = s.executeQuery(sql);
            r.last();

            String jmlsatu = r.getString("jml_satu");
            status = Integer.parseInt(jmlsatu);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal Koneksi" + e);
        }
        return status;
    }

    public static int getDataset_all() {
        int status = 0;
        try {
            Connection c = (Connection) KoneksiDatabase.getKoneksi();
            Statement s = c.createStatement();
            String sql = "select count(*)as jml_satu from dataset_asli";
            ResultSet r = s.executeQuery(sql);
            r.last();
            String jmlsatu = r.getString("jml_satu");
            status = Integer.parseInt(jmlsatu);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal Koneksi" + e);
        }
        return status;
    }

    public static int get_datauji() {
        int datauji = 0;
        try {
            Connection c = (Connection) KoneksiDatabase.getKoneksi();
            Statement s = c.createStatement();
            Statement s1 = c.createStatement();
            String sql = "select * from dataset_konversi where Id NOT IN (Select Id from data_training) ";
            ResultSet r = s.executeQuery(sql);
            while (r.next()) {
                int Id = r.getInt("Id");
                String Nim_Samar = r.getString("Nim");
                double F1 = r.getDouble("F1");
                double F2 = r.getDouble("F2");
                double F3 = r.getDouble("F3");
                double F4 = r.getDouble("F4");
                double F5 = r.getDouble("F5");
                double F6 = r.getDouble("F6");
                double F7 = r.getDouble("F7");
                String Actual = r.getString("Actual");
                int Kelas_y = r.getInt("Kelas_y");
                try {
                    String sql1 = "insert into data_testing (Id, Nim, F1, F2, F3, F4, F5, F6, F7, Actual, Kelas_y) values ('" + Id + "','" + Nim_Samar + "','" + F1 + "','" + F2 + "','" + F3 + "','" + F4 + "','" + F5 + "','" + F6 + "','" + F7 + "','" + Actual + "','" + Kelas_y + "')";
                    System.out.println("sql " + sql1);
                    s1.executeUpdate(sql1);
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "Data Uji Gagal Koneksi " + e);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Data Uji Gagal Koneksi" + e);
        }

        return datauji;
    }

    public static int hapusData() {
        int hapusdata = 0;
        try {
            Connection c = (Connection) KoneksiDatabase.getKoneksi();
            Statement s = c.createStatement();
            Statement s1 = c.createStatement();
            
            String sql = "TRUNCATE table data_training";
            String sql1 = "TRUNCATE table data_testing";
            System.out.println("sql " + sql);
            System.out.println("sql1 " + sql1);
            s.executeUpdate(sql);
            s1.executeUpdate(sql1);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal Hapus data dari database. " + e);
        }
        return hapusdata;
    }

    public static int getDataset_real_angka(String actual, String limit) {
        int status = 0;
        int nilailimit = Integer.valueOf(limit);
        try {
            Connection c = (Connection) KoneksiDatabase.getKoneksi();
            Statement s = c.createStatement();
            Statement s1 = c.createStatement();
            String sql = "SELECT * FROM dataset_konversi WHERE Actual = '" + actual + "' ORDER BY RAND() LIMIT " + nilailimit + "";
            ResultSet r = s.executeQuery(sql);
            while (r.next()) {

                int Id = r.getInt("Id");
                String Nim_Samar = r.getString("Nim");
                double F1 = r.getDouble("F1");
                double F2 = r.getDouble("F2");
                double F3 = r.getDouble("F3");
                double F4 = r.getDouble("F4");
                double F5 = r.getDouble("F5");
                double F6 = r.getDouble("F6");
                double F7 = r.getDouble("F7");
                String Actual = r.getString("Actual");
                int Kelas_y = r.getInt("Kelas_y");

                try {
                    String sql1 = "insert into data_training (Id, Nim, F1, F2, F3, F4, F5, F6, F7, Actual, Kelas_y) values ('" + Id + "','" + Nim_Samar + "','" + F1 + "','" + F2 + "','" + F3 + "','" + F4 + "','" + F5 + "','" + F6 + "','" + F7 + "','" + Actual + "','" + Kelas_y + "')";
                    s1.executeUpdate(sql1);
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "Dataset Gagal Dikoneksikan " + e);
                }

                System.out.println("Aktual " + actual);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal Koneksi" + e);
        }
        return status;
    }

    public double hitunganSvm(double lambdaIn, double cIn, double kons_gamma, double[] fitur, int jml_iterasi, int individu) {
        epsilon = Double.parseDouble(View.jt_epsilon.getText());
        jml_iterasi = Integer.parseInt(View.jt_itermax_svm.getText()) + 1;
        view_kernelrbf = "";
        boolean isAllBerprestasi = true;
        view_kernelrbf = view_kernelrbf + "Individu " + (individu + 1) + "\n";

        numformat = new DecimalFormat("0.0000000");
        numformat1 = new DecimalFormat("0.000000");
        numformat2 = new DecimalFormat("0.00");
        jml_datatraining_2 = 0;
        jml_datauji_2 = 0;
        try {
            Connection c = (Connection) KoneksiDatabase.getKoneksi();
            Statement s = c.createStatement();
            String sql = "select * from data_training";
            ResultSet r = s.executeQuery(sql);
            r.last();

            jml_datatraining = r.getRow();
            fitur_datatraining = new double[jml_datatraining][78];
            fitur_datatraining_2 = new double[jml_datatraining][78];

            int i = 0;
            int i_2 = 0;
            r.beforeFirst();
            while (r.next()) {
                if (fitur[0] == 1) {
                    fitur_datatraining[i][0] = Double.valueOf(r.getString("F1"));
                }
                if (fitur[1] == 1) {
                    fitur_datatraining[i][1] = Double.valueOf(r.getString("F2"));
                }
                if (fitur[2] == 1) {
                    fitur_datatraining[i][2] = Double.valueOf(r.getString("F3"));
                }
                if (fitur[3] == 1) {
                    fitur_datatraining[i][3] = Double.valueOf(r.getString("F4"));
                }
                if (fitur[4] == 1) {
                    fitur_datatraining[i][4] = Double.valueOf(r.getString("F5"));
                }
                if (fitur[5] == 1) {
                    fitur_datatraining[i][5] = Double.valueOf(r.getString("F6"));
                }
                if (fitur[6] == 1) {
                    fitur_datatraining[i][6] = Double.valueOf(r.getString("F7"));
                }
                fitur_datatraining[i][7] = Double.valueOf(r.getString("Kelas_y"));
                String actual = r.getString("actual");

                if (!actual.equals("Layak")) {
                    jml_datatraining_2++;
                    if (fitur[0] == 1) {
                        fitur_datatraining_2[i_2][0] = fitur_datatraining[i][0];
                    }
                    if (fitur[1] == 1) {
                        fitur_datatraining_2[i_2][1] = fitur_datatraining[i][1];
                    }
                    if (fitur[2] == 1) {
                        fitur_datatraining_2[i_2][2] = fitur_datatraining[i][2];
                    }
                    if (fitur[3] == 1) {
                        fitur_datatraining_2[i_2][3] = fitur_datatraining[i][3];
                    }
                    if (fitur[4] == 1) {
                        fitur_datatraining_2[i_2][4] = fitur_datatraining[i][4];
                    }
                    if (fitur[5] == 1) {
                        fitur_datatraining_2[i_2][5] = fitur_datatraining[i][5];
                    }
                    if (fitur[6] == 1) {
                        fitur_datatraining_2[i_2][6] = fitur_datatraining[i][6];
                    }
                    
                    if (actual.equals("kuranglayak")) {
                        fitur_datatraining_2[i_2][7] = 1;
                    } else {
                        fitur_datatraining_2[i_2][7] = -1;
                    }
                    i_2++;
                }
                i++;
            }

            r.close();
            s.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal Koneksi" + e);
        }

        try {
            Connection c = (Connection) KoneksiDatabase.getKoneksi();
            Statement s = c.createStatement();
            String sql = "select * from data_testing";
            ResultSet r = s.executeQuery(sql);
            r.last();

            jml_datauji = r.getRow();
            //////System.out.println("Jumlah Data Uji : "+jml_datauji);
            fitur_datauji = new double[jml_datauji][10];
            fitur_datauji_2 = new double[jml_datauji][10];
            int i = 0;
            r.beforeFirst();
            while (r.next()) {
                if (fitur[0] == 1) {
                    fitur_datauji[i][0] = Double.valueOf(r.getString("F1"));
                }
                if (fitur[1] == 1) {
                    fitur_datauji[i][1] = Double.valueOf(r.getString("F2"));
                }
                if (fitur[2] == 1) {
                    fitur_datauji[i][2] = Double.valueOf(r.getString("F3"));
                }
                if (fitur[3] == 1) {
                    fitur_datauji[i][3] = Double.valueOf(r.getString("F4"));
                }
                if (fitur[4] == 1) {
                    fitur_datauji[i][4] = Double.valueOf(r.getString("F5"));
                }
                if (fitur[5] == 1) {
                    fitur_datauji[i][5] = Double.valueOf(r.getString("F6"));
                }
                if (fitur[6] == 1) {
                    fitur_datauji[i][6] = Double.valueOf(r.getString("F7"));
                }
                
                fitur_datauji[i][8] = Double.valueOf(r.getString("Kelas_y"));
                String actual = r.getString("Actual");
                if (actual.equals("layak")) {
                    fitur_datauji[i][7] = 1;
                } else if (actual.equals("kuranglayak")) {
                    fitur_datauji[i][7] = 2;
                } else {
                    fitur_datauji[i][7] = 3;
                }
                fitur_datauji[i][9] = r.getDouble("Nim");
                i++;

            }
            r.close();
            s.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal Koneksi" + e);
        }

        kernelRbf = new double[jml_datatraining][jml_datatraining];
        kernelRbf_datauji = new double[jml_datatraining][jml_datauji];
        matrixhessian = new double[jml_datatraining][jml_datatraining];
        error_rate = new double[jml_iterasi][jml_datatraining][jml_datatraining];
        sigma_error = new double[jml_iterasi][jml_datatraining];
        alphai = new double[jml_iterasi][jml_datatraining];
        delta_alphai = new double[jml_iterasi][jml_datatraining];
        wxplus = new double[jml_datatraining];
        wxmin = new double[jml_datatraining];
        fx = new double[jml_datatraining][jml_datauji];
        sigma_fx = new double[jml_datauji];
        nilai_fx = new double[jml_datauji];
        fungsi_klasifikasi = new double[jml_datauji];

        maxplus = 0;
        maxmin = 0;

        //Kernel RBF
        for (int i = 0; i < jml_datatraining; i++) {
            for (int j = 0; j < jml_datatraining; j++) {
                double temp = 0;
                for (int f = 0; f < 6; f++) {
                    temp = temp + (Math.pow(fitur_datatraining[i][f] - fitur_datatraining[j][f], 2));
                }
                kernelRbf[i][j] = Math.exp(-Math.pow(Math.sqrt(temp), 2) / (2 * sigma));
                view_kernelrbf = view_kernelrbf + " " + numformat1.format(kernelRbf[i][j]);
                ////System.out.print(" " + numformat1.format(kernelRbf[i][j]));
            }
            view_kernelrbf = view_kernelrbf + "\n";
            // ////System.out.println("");
        }

        //System.out.println("");
        ////System.out.println("Matrix Hessian");
        double maxhessian = 0;
        for (int i = 0; i < jml_datatraining; i++) {
            for (int j = 0; j < jml_datatraining; j++) {
                matrixhessian[i][j] = ((fitur_datatraining[i][7]) * (fitur_datatraining[j][7])) * (kernelRbf[i][j] + (Math.pow(lambdaIn, 2)));
                ////System.out.print(" " + numformat.format(matrixhessian[i][j]));
                if (matrixhessian[i][j] > maxhessian) {
                    maxhessian = matrixhessian[i][j];
                }
                gamma = kons_gamma / maxhessian;
            }
            ////System.out.println("");
        }
        ////System.out.println("");

        double maxdelta_alphai = epsilon;
        int t = 1;
        while (!(maxdelta_alphai < epsilon || t >= jml_iterasi)) {
            //System.out.println("");
            //System.out.println("error rate iterasi = " + (t));
            for (int i = 0; i < jml_datatraining; i++) {
                for (int j = 0; j < jml_datatraining; j++) {
                    error_rate[t][i][j] = alphai[t - 1][i] * matrixhessian[i][j];
                    sigma_error[t][i] += error_rate[t][i][j];
                    ////System.out.print(" " + numformat.format(error_rate[t][i][j]));
                }
                ////System.out.print(" " + numformat.format(sigma_error[t][i]));
                ////System.out.println("");
            }

            //System.out.println("delta alpha i iterasi = " + (t));
            for (int j = 0; j < jml_datatraining; j++) {
                delta_alphai[t][j] = Math.min(Math.max(gamma * (1 - sigma_error[t][j]), (alphai[t - 1][j] * -1)), (cIn - alphai[t - 1][j]));
                if (t == 1 && j == 0) {
                    maxdelta_alphai = delta_alphai[t][j];
                }
                maxdelta_alphai = Math.max(maxdelta_alphai, delta_alphai[t][j]);
                ////System.out.println(" " + numformat.format(delta_alphai[t][j]));
            }

            ////System.out.println("alpha i iterasi = " + (t));
            for (int j = 0; j < jml_datatraining; j++) {
                alphai[t][j] = alphai[t - 1][j] + delta_alphai[t][j];
                //  //System.out.println(" " + numformat.format(alphai[t][j]));
            }
            t++;
        }
        int indeks1 = 0;
        int indeks1_2 = 0;
        int indeksmin1 = 0;
        int indeksmin1_2 = 0;
        maxplus = 0;
        maxplus_2 = 0;
        maxmin = 0;
        maxmin_2 = 0;
        sigma_wxplus = 0;
        sigma_wxmin = 0;
        sigma_wxplus_2 = 0;
        sigma_wxmin_2 = 0;
        for (int i = 0; i < getKriteria("layak"); i++) {
            if (alphai[jml_iterasi - 1][i] > maxplus) {
                maxplus = (alphai[jml_iterasi - 1][i]);
                indeks1 = i;
            }
        }

//        //System.out.println("maks kelas 1 =" + indeks1 + " - " + numformat.format(maxplus));
        for (int i = getKriteria("layak"); i < jml_datatraining; i++) {
            if (alphai[jml_iterasi - 1][i] > maxmin) {
                maxmin = alphai[jml_iterasi - 1][i];
                indeksmin1 = i;
            }
        }

        ////System.out.println("maks kelas -1 =" + indeksmin1 + " - " + numformat.format(maxmin));
        ////System.out.println("");
        //System.out.println("K(xi,x+)");
        for (int j = 0; j < jml_datatraining; j++) {
            ////System.out.println(" " + numformat.format(kernelRbf[j][indeks1]));
        }
        //System.out.println("K(xi,x-)");
        for (int j = 0; j < jml_datatraining; j++) {
            //System.out.println(" " + numformat.format(kernelRbf[j][indeksmin1]));
        }

        //System.out.println("");
        //System.out.println("w.x+");
        for (int j = 0; j < jml_datatraining; j++) {
            wxplus[j] = alphai[jml_iterasi - 1][j] * fitur_datatraining[j][7] * kernelRbf[j][indeks1];
            sigma_wxplus = (sigma_wxplus + wxplus[j]);
            //System.out.println(" " + numformat1.format(wxplus[j]));
        }
        //System.out.println("" + numformat1.format(sigma_wxplus));

        //System.out.println("");
        //System.out.println("w.x-");
        for (int j = 0; j < jml_datatraining; j++) {
            wxmin[j] = (alphai[jml_iterasi - 1][j] * fitur_datatraining[j][7] * kernelRbf[j][indeksmin1]);
            sigma_wxmin = sigma_wxmin + wxmin[j];
            //System.out.println(" " + numformat1.format(wxmin[j]));
        }
        //System.out.println(" " + numformat1.format(sigma_wxmin));

        nilai_b = (-0.5) * (sigma_wxplus + sigma_wxmin);
        //System.out.println("");
        //System.out.println("nilai B");
        //System.out.println(numformat1.format(nilai_b));

        //System.out.println("");
        //System.out.println("Kernel data uji");
        for (int i = 0; i < jml_datatraining; i++) {
            for (int j = 0; j < jml_datauji; j++) {
                double temp = 0;
                for (int f = 0; f < 6; f++) {
                    temp = temp + (Math.pow(fitur_datatraining[i][f] - fitur_datauji[j][f], 2));
                }
                kernelRbf_datauji[i][j] = Math.exp(-Math.pow(Math.sqrt(temp), 2) / (2 * sigma));
                fx[i][j] = (alphai[jml_iterasi - 1][i] * fitur_datatraining[i][7] * kernelRbf_datauji[i][j]);
                sigma_fx[j] = sigma_fx[j] + fx[i][j];
                //System.out.print(" " + numformat.format(kernelRbf_datauji[i][j]));
                //System.out.print(" " + numformat.format(fx[i][j]));

            }

            //System.out.println("");
        }

        //System.out.println("");
        //System.out.println("nilai sigma data uji");
        for (int j = 0; j < jml_datauji; j++) {
            //System.out.print(" " + numformat.format(sigma_fx[j]));
        }

        //System.out.println("");
        //System.out.println("nilai fx");
        for (int j = 0; j < jml_datauji; j++) {
            nilai_fx[j] = sigma_fx[j] + nilai_b;
            //System.out.print(" " + numformat.format(nilai_fx[j]));
        }

        //System.out.println("");
        //System.out.println("fungsi klasifikasi");
        for (int j = 0; j < jml_datauji; j++) {
            fungsi_klasifikasi[j] = Math.signum(nilai_fx[j]);
            //System.out.print(" " + (int) fungsi_klasifikasi[j]);
            if ((int) fungsi_klasifikasi[j] == -1) {
                isAllBerprestasi = false;
                jml_datauji_2++;
            }
        }
        fitur_datauji_2 = new double[jml_datauji][10];
        int indeks_2 = 0;
        for (int i = 0; i < jml_datauji; i++) {
            if ((int) fungsi_klasifikasi[i] == -1) {
                for (int j = 0; j < 10; j++) {
                    fitur_datauji_2[indeks_2][j] = fitur_datauji[i][j];
                }
                indeks_2++;
            }
        }

        alphai_2 = new double[jml_iterasi][jml_datatraining_2];
        kernelRbf_datauji_2 = new double[jml_datatraining_2][jml_datauji_2];
        kernelRbf_2 = new double[jml_datatraining_2][jml_datatraining_2];
        matrixhessian_2 = new double[jml_datatraining_2][jml_datatraining_2];
        error_rate_2 = new double[jml_iterasi][jml_datatraining_2][jml_datatraining_2];
        sigma_error_2 = new double[jml_iterasi][jml_datatraining_2];
        delta_alphai_2 = new double[jml_iterasi][jml_datatraining_2];
        wxplus_2 = new double[jml_datatraining_2];
        wxmin_2 = new double[jml_datatraining_2];
        fx_2 = new double[jml_datatraining_2][jml_datauji_2];
        sigma_fx_2 = new double[jml_datauji_2];
        nilai_fx_2 = new double[jml_datauji_2];
        fungsi_klasifikasi_2 = new double[jml_datauji_2];

        if (isAllBerprestasi == false) {
            //System.out.println("");
            //System.out.println("Kernel RBF Level 2");
            for (int x = 0; x < jml_datatraining_2; x++) {
                for (int y = 0; y < jml_datatraining_2; y++) {
                    double temp = 0;
                    for (int f = 0; f < 6; f++) {
                        temp = temp + (Math.pow(fitur_datatraining_2[x][f] - fitur_datatraining_2[y][f], 2));
                    }
                    kernelRbf_2[x][y] = Math.exp(-Math.pow(Math.sqrt(temp), 2) / (2 * sigma));
                    //System.out.print(" " + numformat1.format(kernelRbf_2[x][y]));
                }
                //System.out.println("");
            }

            //System.out.println("");
            //System.out.println("Matrix Hessian Level 2");
            for (int i = 0; i < jml_datatraining_2; i++) {
                for (int j = 0; j < jml_datatraining_2; j++) {
                    matrixhessian_2[i][j] = ((fitur_datatraining_2[i][7]) * (fitur_datatraining_2[j][7])) * (kernelRbf_2[i][j] + (Math.pow(lambdaIn, 2)));
                    //System.out.print(" " + numformat.format(matrixhessian_2[i][j]));
                }
            }//System.out.println("");

//            }
            double maxdelta_alphai_2 = epsilon;
            t = 1;
            //iterasi_level2(t, const_gamma, cIn);
            while (!(maxdelta_alphai_2 < epsilon || t >= jml_iterasi)) {
                //System.out.println("");
                //System.out.println("error rate Level 2 iterasi = " + (t));
                for (int i = 0; i < jml_datatraining_2; i++) {
                    sigma_error_2[t][i] = 0;
                    for (int j = 0; j < jml_datatraining_2; j++) {
                        error_rate_2[t][i][j] = alphai_2[t - 1][i] * matrixhessian_2[i][j];
                        sigma_error_2[t][i] += error_rate_2[t][i][j];
                        //System.out.print(" " + numformat.format(error_rate_2[t][i][j]));
                    }
                    //System.out.print(" " + numformat.format(sigma_error_2[t][i]));
                    //System.out.println("");
                }

                //System.out.println("delta alpha i level 2 iterasi = " + (t));
                for (int j = 0; j < jml_datatraining_2; j++) {
                    delta_alphai_2[t][j] = Math.min(Math.max(gamma * (1 - sigma_error_2[t][j]), -alphai_2[t - 1][j]), (cIn - alphai_2[t - 1][j]));
                    if (t == 1 && j == 0) {
                        maxdelta_alphai_2 = delta_alphai_2[t][j];
                    }
                    maxdelta_alphai_2 = Math.max(maxdelta_alphai_2, delta_alphai_2[t][j]);
                    //System.out.println(" " + numformat.format(delta_alphai_2[t][j]));
                }

                //System.out.println("alpha i level 2 iterasi = " + (t));
                for (int j = 0; j < jml_datatraining_2; j++) {
                    alphai_2[t][j] = alphai_2[t - 1][j] + delta_alphai_2[t][j];
                    //System.out.println(" " + numformat.format(alphai_2[t][j]));

                }
                t++;
            }

            //System.out.println(indeks1_2);
            //System.out.println(maxplus_2);
            for (int i = 0; i < getKriteria("kuranglayak"); i++) {
                if (alphai_2[jml_iterasi - 1][i] > maxplus_2) {
                    maxplus_2 = alphai_2[jml_iterasi - 1][i];
                    indeks1_2 = i;
                }
            }
            //System.out.println("maks level 2 kelas 1 =" + indeks1_2 + " - " + numformat.format(maxplus_2));            
            for (int i = getKriteria("tidaklayak"); i < jml_datatraining_2; i++) {
                if (alphai_2[jml_iterasi - 1][i] > maxmin_2) {
                    maxmin_2 = alphai_2[jml_iterasi - 1][i];
                    indeksmin1_2 = i;
                }
            }

            //System.out.println(indeksmin1_2);
            //System.out.println(maxmin_2);
            //System.out.println("maks level 2 kelas -1 =" + indeksmin1_2 + " - " + numformat.format(maxmin_2));
            //System.out.println("K(xi,x+)");
            for (int j = 0; j < jml_datatraining_2; j++) {
                //System.out.println(" " + numformat.format(kernelRbf_2[j][indeks1_2]));
            }
            //System.out.println("K(xi,x-)");
            for (int j = 0; j < jml_datatraining_2; j++) {
                //System.out.println(" " + numformat.format(kernelRbf_2[j][indeksmin1_2]));
            }

            //System.out.println("");
            //System.out.println("w.x+");
            for (int j = 0; j < jml_datatraining_2; j++) {
                wxplus_2[j] = alphai_2[jml_iterasi - 1][j] * fitur_datatraining_2[j][7] * kernelRbf_2[j][indeks1_2];
                sigma_wxplus_2 = (sigma_wxplus_2 + wxplus_2[j]);
                //System.out.println(" " + numformat1.format(wxplus_2[j]));
            }
            //System.out.println("" + numformat1.format(sigma_wxplus_2));

            //System.out.println("");
            //System.out.println("w.x-");
            for (int j = 0; j < jml_datatraining_2; j++) {
                wxmin_2[j] = (alphai_2[jml_iterasi - 1][j] * fitur_datatraining_2[j][7] * kernelRbf_2[j][indeksmin1_2]);
                sigma_wxmin_2 = sigma_wxmin_2 + wxmin_2[j];
                //System.out.println(" " + numformat1.format(wxmin_2[j]));
            }
            //System.out.println(" " + numformat1.format(sigma_wxmin_2));

            nilai_b_2 = (-0.5) * (sigma_wxplus_2 + sigma_wxmin_2);
            //System.out.println("");
            //System.out.println("nilai B");
            //System.out.println(numformat1.format(nilai_b_2));

            //System.out.println("");
            //System.out.println("Kernel data uji");
            for (int i = 0; i < jml_datatraining_2; i++) {
                for (int j = 0; j < jml_datauji_2; j++) {
                    double temp = 0;
                    for (int f = 0; f < 6; f++) {
                        temp = temp + (Math.pow(fitur_datatraining_2[i][f] - fitur_datauji_2[j][f], 2));
                    }
                    kernelRbf_datauji_2[i][j] = Math.exp(-Math.pow(Math.sqrt(temp), 2) / (2 * 1));
                    fx_2[i][j] = (alphai_2[jml_iterasi - 1][i] * fitur_datatraining_2[i][7] * kernelRbf_datauji_2[i][j]);
                    sigma_fx_2[j] = sigma_fx_2[j] + fx_2[i][j];
                    //System.out.print(" " + numformat.format(kernelRbf_datauji_2[x][y]));
                    //System.out.print(" " + numformat.format(fx_2[x][y]));
                }
                //System.out.println("");
            }

            //System.out.println("");
            //System.out.println("nilai sigma data uji");
            for (int j = 0; j < jml_datauji_2; j++) {
                //System.out.print(" " + numformat.format(sigma_fx_2[j]));
            }
            //System.out.println("");
            //System.out.println("nilai fx");
            for (int j = 0; j < jml_datauji_2; j++) {
                nilai_fx_2[j] = sigma_fx_2[j] + nilai_b_2;
                //System.out.print(" " + numformat.format(nilai_fx_2[j]));
            }

            //System.out.println("");
            //System.out.println("fungsi klasifikasi");
            for (int j = 0; j < jml_datauji_2; j++) {
                fungsi_klasifikasi_2[j] = Math.signum(nilai_fx_2[j]);
                //System.out.print(" " + (int) fungsi_klasifikasi_2[j]);
            }
        }

        perhitungan_fx = new Object[jml_datauji][5];
        confusion_matrix = new double[3][3];
        int indeks = 0;
        for (int i = 0; i < jml_datauji; i++) {
            perhitungan_fx[i][0] = fitur_datauji[i][9];
            perhitungan_fx[i][1] = nilai_fx[i];
            if (fungsi_klasifikasi[i] == 1) {
                perhitungan_fx[i][3] = "layak";
            }

            if (fitur_datauji[i][9] == fitur_datauji_2[indeks][9]) {
                perhitungan_fx[i][2] = nilai_fx_2[indeks];
                if (fungsi_klasifikasi_2[indeks] == 1) {
                    perhitungan_fx[i][3] = "kuranglayak";
                } else {
                    perhitungan_fx[i][3] = "tidaklayak";
                }
                indeks++;
            }
            if (fitur_datauji[i][7] == 1) {
                perhitungan_fx[i][4] = "layak";
            } else if (fitur_datauji[i][7] == 2) {
                perhitungan_fx[i][4] = "kuranglayak";
            } else {
                perhitungan_fx[i][4] = "tidaklayak";
            }
        }
        //System.out.println("");
        //System.out.println("hasil perhitungan f(x)");
        for (int i = 0; i < perhitungan_fx.length; i++) {
            for (int j = 0; j < 5; j++) {
                //System.out.print("\t\t" + perhitungan_fx[i][j]);
            }
            //System.out.println(" ");
        }

        //fungsi klasifikasi
        for (int i = 0; i < jml_datauji; i++) {
            if (perhitungan_fx[i][3] == "layak" && perhitungan_fx[i][4] == "layak") {
                confusion_matrix[0][0]++;
            } else if (perhitungan_fx[i][3] == "layak" && perhitungan_fx[i][4] == "kuranglayak") {
                confusion_matrix[1][0]++;
            } else if (perhitungan_fx[i][3] == "layak" && perhitungan_fx[i][4] == "tidaklayak") {
                confusion_matrix[2][0]++;
            } else if (perhitungan_fx[i][3] == "kuranglayak" && perhitungan_fx[i][4] == "layak") {
                confusion_matrix[0][1]++;
            } else if (perhitungan_fx[i][3] == "kuranglayak" && perhitungan_fx[i][4] == "kuranglayak") {
                confusion_matrix[1][1]++;
            } else if (perhitungan_fx[i][3] == "kuranglayak" && perhitungan_fx[i][4] == "tidaklayak") {
                confusion_matrix[2][1]++;
            } else if (perhitungan_fx[i][3] == "tidaklayak" && perhitungan_fx[i][4] == "layak") {
                confusion_matrix[0][2]++;
            } else if (perhitungan_fx[i][3] == "tidaklayak" && perhitungan_fx[i][4] == "kuranglayak") {
                confusion_matrix[1][2]++;
            } else if (perhitungan_fx[i][3] == "tidaklayak" && perhitungan_fx[i][4] == "tidaklayak") {
                confusion_matrix[2][2]++;
            }
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                //System.out.print(" " + confusion_matrix[i][j]);
            }
            //System.out.println("");
        }

        tp = confusion_matrix[0][0] + confusion_matrix[1][1] + confusion_matrix[2][2];
        tn = (confusion_matrix[0][0] + confusion_matrix[1][1]) + (confusion_matrix[0][0] + confusion_matrix[0][2]) + (confusion_matrix[1][1] + confusion_matrix[2][2]);
        fp = (confusion_matrix[1][0] + confusion_matrix[2][0]) + (confusion_matrix[0][1] + confusion_matrix[2][1]) + (confusion_matrix[0][2] + confusion_matrix[1][2]);
        fn = (confusion_matrix[0][1] + confusion_matrix[0][2]) + (confusion_matrix[1][0] + confusion_matrix[1][2]) + (confusion_matrix[2][0] + confusion_matrix[2][1]);
        //System.out.println("Tp" + tp);
        //System.out.println("Tn" + tn);
        //System.out.println("fp" + fp);
        //System.out.println("fn" + fn);
        akurasi = (tp + tn) / (tp + tn + fp + fn);
        //System.out.println("Akurasi");
        //System.out.println(" " + numformat2.format(akurasi));
        return akurasi;
    }

    //error rate, delta alpha i, alpha i lvl 1
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        svm Svm = new svm();
        double fitur[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0};
        Svm.hitunganSvm(0.005005, 20.8, 0.26, fitur, 3, 3);
    }

    public String getPerhitunganSvm() {
        return view_kernelrbf;
    }
}
